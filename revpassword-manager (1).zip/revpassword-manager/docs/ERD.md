# Entity-Relationship Diagram (ERD)

## RevPassword Manager Database Schema

### Database: revpassword_db

## Tables

### 1. users
**Purpose**: Stores user account information

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| user_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique user identifier |
| username | VARCHAR(50) | UNIQUE, NOT NULL | User's login username |
| email | VARCHAR(100) | UNIQUE, NOT NULL | User's email address |
| full_name | VARCHAR(100) | NOT NULL | User's full name |
| master_password | VARCHAR(255) | NOT NULL | BCrypt hashed master password |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Account creation timestamp |
| updated_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP ON UPDATE | Last update timestamp |
| is_active | BOOLEAN | DEFAULT TRUE | Account active status |

**Indexes**:
- PRIMARY KEY (user_id)
- UNIQUE INDEX (username)
- UNIQUE INDEX (email)
- INDEX (username)
- INDEX (email)

---

### 2. security_questions
**Purpose**: Stores security questions for password recovery

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| question_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique question identifier |
| user_id | INT | FOREIGN KEY, NOT NULL | Reference to users table |
| question | TEXT | NOT NULL | The security question text |
| answer_hash | VARCHAR(255) | NOT NULL | BCrypt hashed answer |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Question creation timestamp |

**Relationships**:
- FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE

**Indexes**:
- PRIMARY KEY (question_id)
- INDEX (user_id)

---

### 3. password_vault
**Purpose**: Stores encrypted passwords for user accounts

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| vault_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique vault entry identifier |
| user_id | INT | FOREIGN KEY, NOT NULL | Reference to users table |
| account_name | VARCHAR(100) | NOT NULL | Name of the account/service |
| username | VARCHAR(100) | NULL | Username for the account |
| encrypted_password | TEXT | NOT NULL | AES encrypted password |
| website_url | VARCHAR(255) | NULL | URL of the service |
| notes | TEXT | NULL | Additional notes |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Entry creation timestamp |
| updated_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP ON UPDATE | Last update timestamp |

**Relationships**:
- FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE

**Indexes**:
- PRIMARY KEY (vault_id)
- INDEX (user_id, account_name)
- INDEX (user_id)

---

### 4. verification_codes
**Purpose**: Stores temporary verification codes for sensitive operations

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| code_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique code identifier |
| user_id | INT | FOREIGN KEY, NOT NULL | Reference to users table |
| verification_code | VARCHAR(10) | NOT NULL | The verification code |
| purpose | VARCHAR(50) | NOT NULL | Purpose of the code |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Code creation timestamp |
| expires_at | TIMESTAMP | NOT NULL | Code expiration timestamp |
| is_used | BOOLEAN | DEFAULT FALSE | Whether code has been used |

**Relationships**:
- FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE

**Indexes**:
- PRIMARY KEY (code_id)
- INDEX (user_id, verification_code)
- INDEX (expires_at)

---

### 5. audit_log (Optional)
**Purpose**: Tracks user actions for security auditing

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| log_id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique log identifier |
| user_id | INT | FOREIGN KEY, NULL | Reference to users table |
| action | VARCHAR(100) | NOT NULL | Action performed |
| details | TEXT | NULL | Additional details |
| ip_address | VARCHAR(45) | NULL | User's IP address |
| timestamp | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Action timestamp |

**Relationships**:
- FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL

**Indexes**:
- PRIMARY KEY (log_id)
- INDEX (user_id, timestamp)

---

## Relationships Diagram

```
┌─────────────────┐
│     users       │
│─────────────────│
│ PK: user_id     │
│ username        │
│ email           │
│ full_name       │
│ master_password │
│ created_at      │
│ updated_at      │
│ is_active       │
└────────┬────────┘
         │
         │ 1:N
         │
    ┌────┴────────────────────────────┬─────────────────────┬───────────────────┐
    │                                 │                     │                   │
    │                                 │                     │                   │
┌───▼─────────────────┐   ┌───────────▼─────────┐   ┌─────▼──────────────┐   │
│ security_questions  │   │   password_vault    │   │verification_codes  │   │
│─────────────────────│   │─────────────────────│   │────────────────────│   │
│ PK: question_id     │   │ PK: vault_id        │   │ PK: code_id        │   │
│ FK: user_id         │   │ FK: user_id         │   │ FK: user_id        │   │
│ question            │   │ account_name        │   │ verification_code  │   │
│ answer_hash         │   │ username            │   │ purpose            │   │
│ created_at          │   │ encrypted_password  │   │ created_at         │   │
└─────────────────────┘   │ website_url         │   │ expires_at         │   │
                          │ notes               │   │ is_used            │   │
                          │ created_at          │   └────────────────────┘   │
                          │ updated_at          │                            │
                          └─────────────────────┘                            │
                                                                              │
                                                                  ┌───────────▼──────┐
                                                                  │   audit_log      │
                                                                  │──────────────────│
                                                                  │ PK: log_id       │
                                                                  │ FK: user_id      │
                                                                  │ action           │
                                                                  │ details          │
                                                                  │ ip_address       │
                                                                  │ timestamp        │
                                                                  └──────────────────┘
```

## Cardinality

- **users → security_questions**: One-to-Many (1:N)
  - One user can have multiple security questions
  - Each security question belongs to one user

- **users → password_vault**: One-to-Many (1:N)
  - One user can have multiple password entries
  - Each password entry belongs to one user

- **users → verification_codes**: One-to-Many (1:N)
  - One user can have multiple verification codes
  - Each verification code belongs to one user

- **users → audit_log**: One-to-Many (1:N)
  - One user can have multiple audit log entries
  - Each audit log entry belongs to one user (or NULL if user is deleted)

## Data Flow

1. **User Registration**:
   - Insert into `users` table
   - Optionally insert into `security_questions` table

2. **Password Storage**:
   - User logs in (verify against `users` table)
   - Insert encrypted password into `password_vault` table

3. **Password Retrieval**:
   - User logs in and requests password
   - Retrieve from `password_vault` table
   - Decrypt using master password

4. **Password Recovery**:
   - Retrieve security questions from `security_questions` table
   - Verify answers
   - Generate verification code in `verification_codes` table
   - Allow password reset

5. **Verification Code**:
   - Insert into `verification_codes` table with expiration time
   - Verify and mark as used
   - Cleanup expired codes periodically

## Security Considerations

1. **Password Storage**:
   - Master passwords stored as BCrypt hashes (never plain text)
   - Account passwords encrypted with AES using master password as key
   - Security question answers hashed with BCrypt

2. **Cascading Deletes**:
   - When a user is deleted, all related data is removed (CASCADE)
   - Audit logs preserve user_id as NULL for historical tracking

3. **Indexes**:
   - Indexes on frequently queried fields for performance
   - Composite indexes for common query patterns

4. **Constraints**:
   - UNIQUE constraints on username and email prevent duplicates
   - NOT NULL constraints ensure data integrity
   - Foreign key constraints maintain referential integrity

## Database Size Estimates

For 10,000 users with average usage:
- users: ~500 KB
- security_questions (2 per user): ~1.5 MB
- password_vault (20 entries per user): ~15 MB
- verification_codes: ~500 KB (with cleanup)
- audit_log: ~10 MB (varies with usage)

**Total estimated size**: ~27.5 MB for 10,000 users

## Backup and Maintenance

1. **Regular Backups**: Daily automated backups recommended
2. **Cleanup Tasks**:
   - Delete expired verification codes daily
   - Archive old audit logs monthly
3. **Index Maintenance**: Rebuild indexes monthly
4. **Performance Monitoring**: Monitor query performance and optimize as needed
