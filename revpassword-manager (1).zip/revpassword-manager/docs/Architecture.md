# Application Architecture

## RevPassword Manager - Layered Architecture

## Architecture Overview

RevPassword Manager follows a **Layered Architecture** pattern (also known as N-Tier Architecture) which provides clear separation of concerns, maintainability, and testability.

```
┌─────────────────────────────────────────────────────────────────┐
│                      PRESENTATION LAYER                         │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │              MainController.java                          │  │
│  │  - Console-based User Interface                           │  │
│  │  - User input handling                                    │  │
│  │  - Menu navigation                                        │  │
│  │  - Display formatting                                     │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                       SERVICE LAYER                             │
│  ┌───────────────────┬───────────────────┬────────────────────┐ │
│  │  UserService      │PasswordVaultSvc   │ SecurityService    │ │
│  │  ───────────────  │ ─────────────────  │ ───────────────── │ │
│  │  - Registration   │ - Add password    │ - Security Q&A     │ │
│  │  - Login/Auth     │ - List passwords  │ - Verification     │ │
│  │  - Profile update │ - Update password │ - Code generation  │ │
│  │  - Password reset │ - Delete password │ - Answer verify    │ │
│  │                   │ - Search          │                    │ │
│  │                   │ - Generate pwd    │                    │ │
│  └───────────────────┴───────────────────┴────────────────────┘ │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                    DATA ACCESS LAYER (DAO)                      │
│  ┌───────────────┬──────────────┬──────────────┬─────────────┐  │
│  │   UserDAO     │PasswordVault │  Security    │Verification │  │
│  │               │     DAO      │ QuestionDAO  │  CodeDAO    │  │
│  │  ────────────  │ ──────────── │ ──────────── │ ─────────── │  │
│  │  - Create     │ - Add        │ - Add        │ - Create    │  │
│  │  - FindById   │ - GetAll     │ - GetByUser  │ - FindValid │  │
│  │  - FindByName │ - GetById    │ - GetById    │ - MarkUsed  │  │
│  │  - FindByEmail│ - Search     │ - Update     │ - Cleanup   │  │
│  │  - Update     │ - Update     │ - Delete     │             │  │
│  │  - Delete     │ - Delete     │              │             │  │
│  └───────────────┴──────────────┴──────────────┴─────────────┘  │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                        UTILITY LAYER                            │
│  ┌────────────────┬───────────────┬──────────────┬───────────┐  │
│  │DatabaseConnect │EncryptionUtil │PasswordHash  │Password   │  │
│  │     ion        │               │    Util      │Generator  │  │
│  │  ────────────  │ ─────────────  │ ──────────── │ ───────── │  │
│  │  - Singleton   │ - AES Encrypt │ - BCrypt Hash│ - Generate│  │
│  │  - Get Conn    │ - AES Decrypt │ - Verify Hash│ - Validate│  │
│  │  - Close Conn  │               │              │           │  │
│  │                │               │              │           │  │
│  └────────────────┴───────────────┴──────────────┴───────────┘  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │              ValidationUtil                                │ │
│  │              ──────────────                                │ │
│  │              - Email validation                            │ │
│  │              - Username validation                         │ │
│  │              - Password strength check                     │ │
│  └────────────────────────────────────────────────────────────┘ │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                         MODEL LAYER                             │
│  ┌───────────────┬──────────────┬──────────────┬─────────────┐  │
│  │     User      │PasswordEntry │  Security    │Verification │  │
│  │               │              │   Question   │    Code     │  │
│  │  ────────────  │ ──────────── │ ──────────── │ ─────────── │  │
│  │  - userId     │ - vaultId    │ - questionId │ - codeId    │  │
│  │  - username   │ - userId     │ - userId     │ - userId    │  │
│  │  - email      │ - account    │ - question   │ - code      │  │
│  │  - masterPwd  │ - username   │ - answerHash │ - purpose   │  │
│  │  - fullName   │ - encPwd     │ - createdAt  │ - expiresAt │  │
│  │  - timestamps │ - websiteUrl │              │ - isUsed    │  │
│  └───────────────┴──────────────┴──────────────┴─────────────┘  │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                      DATABASE LAYER                             │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                MySQL Database                           │    │
│  │  ─────────────────────────────────────────────────────   │    │
│  │  Tables:                                                │    │
│  │  - users                                                │    │
│  │  - password_vault                                       │    │
│  │  - security_questions                                   │    │
│  │  - verification_codes                                   │    │
│  │  - audit_log (optional)                                 │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

## Cross-Cutting Concerns

```
┌─────────────────────────────────────────────────────────────────┐
│                   LOGGING (Log4j 2)                             │
│  - Application flow logging                                     │
│  - Error logging                                                │
│  - Debug information                                            │
│  - Audit trail                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                   SECURITY                                      │
│  - Password encryption (AES-256)                                │
│  - Password hashing (BCrypt)                                    │
│  - Input validation                                             │
│  - SQL injection prevention (PreparedStatements)                │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│              EXCEPTION HANDLING                                 │
│  - Try-catch blocks in DAOs                                     │
│  - Service layer exception handling                             │
│  - User-friendly error messages                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Layer Descriptions

### 1. Presentation Layer (Controller)
**Responsibility**: User interaction and display

**Components**:
- `MainController.java`: Main console interface controller

**Key Features**:
- Menu navigation
- User input collection
- Data formatting for display
- Input validation at UI level
- Error message display

**Dependencies**: Service Layer

---

### 2. Service Layer (Business Logic)
**Responsibility**: Core business logic and orchestration

**Components**:
- `UserService.java`: User management operations
- `PasswordVaultService.java`: Password vault operations
- `SecurityService.java`: Security question and verification code management

**Key Features**:
- Business rule enforcement
- Transaction coordination
- Data validation
- Service-to-service communication
- Error handling and logging

**Dependencies**: DAO Layer, Utility Layer

---

### 3. Data Access Layer (DAO)
**Responsibility**: Database operations and data persistence

**Components**:
- `UserDAO.java`: User CRUD operations
- `PasswordVaultDAO.java`: Password entry CRUD operations
- `SecurityQuestionDAO.java`: Security question CRUD operations
- `VerificationCodeDAO.java`: Verification code CRUD operations

**Key Features**:
- SQL query execution
- Result set mapping
- Prepared statements for security
- Connection management
- Database exception handling

**Dependencies**: Utility Layer (DatabaseConnection), Model Layer

---

### 4. Utility Layer
**Responsibility**: Reusable helper functions

**Components**:
- `DatabaseConnection.java`: Database connection management (Singleton)
- `EncryptionUtil.java`: AES encryption/decryption
- `PasswordHashUtil.java`: BCrypt password hashing
- `PasswordGenerator.java`: Strong password generation
- `ValidationUtil.java`: Input validation

**Key Features**:
- Encryption/decryption services
- Password hashing and verification
- Random password generation
- Input validation rules
- Database connection pooling

**Dependencies**: None (standalone utilities)

---

### 5. Model Layer
**Responsibility**: Data representation

**Components**:
- `User.java`: User entity
- `PasswordEntry.java`: Password vault entry entity
- `SecurityQuestion.java`: Security question entity
- `VerificationCode.java`: Verification code entity

**Key Features**:
- Plain Old Java Objects (POJOs)
- Data encapsulation
- Getters and setters
- Constructors for different use cases
- Override equals, hashCode, toString

**Dependencies**: None

---

### 6. Database Layer
**Responsibility**: Data persistence and storage

**Components**:
- MySQL Database
- Tables: users, password_vault, security_questions, verification_codes, audit_log

**Key Features**:
- ACID transactions
- Foreign key constraints
- Indexes for performance
- Triggers (if needed)
- Stored procedures (optional)

---

## Data Flow Examples

### Example 1: User Registration

```
User Input → MainController → UserService → UserDAO → Database
                                    ↓
                             PasswordHashUtil
                                    ↓
                             ValidationUtil
```

**Detailed Flow**:
1. User enters registration details in `MainController`
2. `MainController` calls `UserService.registerUser()`
3. `UserService` validates input using `ValidationUtil`
4. `UserService` hashes password using `PasswordHashUtil`
5. `UserService` calls `UserDAO.createUser()`
6. `UserDAO` executes SQL INSERT
7. Database stores user data
8. Success/failure propagates back to user

---

### Example 2: Adding Password Entry

```
User Input → MainController → PasswordVaultService → PasswordVaultDAO → Database
                                    ↓
                             EncryptionUtil (encrypt)
                                    ↓
                             Master Password
```

**Detailed Flow**:
1. User enters password details in `MainController`
2. `MainController` calls `PasswordVaultService.addPassword()`
3. `PasswordVaultService` encrypts password using `EncryptionUtil`
4. `PasswordVaultService` calls `PasswordVaultDAO.addPasswordEntry()`
5. `PasswordVaultDAO` executes SQL INSERT with encrypted password
6. Database stores encrypted password entry
7. Success/failure propagates back to user

---

### Example 3: Viewing Password

```
User Input → MainController → PasswordVaultService → PasswordVaultDAO → Database
                    ↓                     ↓
            Master Password      EncryptionUtil (decrypt)
                                         ↓
                                  Display Password
```

**Detailed Flow**:
1. User selects password entry to view
2. `MainController` prompts for master password re-entry
3. `MainController` calls `PasswordVaultService.getDecryptedPassword()`
4. `PasswordVaultService` calls `PasswordVaultDAO.getPasswordEntryById()`
5. `PasswordVaultDAO` retrieves encrypted password from database
6. `PasswordVaultService` decrypts using `EncryptionUtil` and master password
7. Decrypted password displayed to user

---

## Design Patterns Used

### 1. Layered Architecture Pattern
- Clear separation of concerns
- Each layer has specific responsibility
- Unidirectional dependencies (top to bottom)

### 2. Singleton Pattern
- `DatabaseConnection`: Ensures single database connection manager instance

### 3. Data Access Object (DAO) Pattern
- Abstracts database operations
- Provides clean interface for data access

### 4. Service Facade Pattern
- Service layer provides simplified interface to complex subsystems
- Coordinates operations across multiple DAOs

### 5. Model-View-Controller (MVC) Variation
- Model: Entity classes
- View: Console output in Controller
- Controller: MainController + Services

---

## Security Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    SECURITY LAYERS                              │
├─────────────────────────────────────────────────────────────────┤
│ 1. Input Validation                                             │
│    - Username format validation                                 │
│    - Email format validation                                    │
│    - Password strength checking                                 │
├─────────────────────────────────────────────────────────────────┤
│ 2. Authentication                                               │
│    - Username/password verification                             │
│    - BCrypt password hashing (cost factor 12)                   │
│    - Master password verification                               │
├─────────────────────────────────────────────────────────────────┤
│ 3. Authorization                                                │
│    - User ownership verification                                │
│    - Master password re-entry for sensitive operations          │
├─────────────────────────────────────────────────────────────────┤
│ 4. Data Encryption                                              │
│    - AES-256 encryption for stored passwords                    │
│    - Master password as encryption key                          │
│    - Base64 encoding for storage                                │
├─────────────────────────────────────────────────────────────────┤
│ 5. SQL Injection Prevention                                     │
│    - Prepared statements for all queries                        │
│    - Parameter binding                                          │
│    - No string concatenation in SQL                             │
├─────────────────────────────────────────────────────────────────┤
│ 6. Audit Trail                                                  │
│    - Logging all critical operations                            │
│    - User activity tracking                                     │
│    - Error logging                                              │
└─────────────────────────────────────────────────────────────────┘
```

---

## Technology Stack

| Layer | Technology | Purpose |
|-------|------------|---------|
| Presentation | Java Scanner | Console I/O |
| Service | Java 11 | Business logic |
| Data Access | JDBC | Database connectivity |
| Database | MySQL 8.0 | Data persistence |
| Logging | Log4j 2 | Application logging |
| Testing | JUnit 5 | Unit testing |
| Security | BCrypt | Password hashing |
| Security | AES-256 | Password encryption |
| Build | Maven | Dependency management |

---

## Advantages of This Architecture

1. **Separation of Concerns**: Each layer has a single, well-defined responsibility

2. **Maintainability**: Changes in one layer don't affect other layers

3. **Testability**: Each layer can be tested independently

4. **Reusability**: Utility classes and services can be reused

5. **Scalability**: Easy to add new features or modify existing ones

6. **Security**: Multiple security layers provide defense in depth

7. **Code Organization**: Clear structure makes navigation easy

---

## Future Enhancements

1. **API Layer**: Add REST API for web/mobile clients
2. **Caching Layer**: Add Redis for frequently accessed data
3. **Message Queue**: Add RabbitMQ for asynchronous operations
4. **Microservices**: Split into separate services (Auth, Vault, etc.)
5. **Cloud Migration**: Move to cloud database (AWS RDS, Azure SQL)

---

## Performance Considerations

1. **Connection Pooling**: Database connections are managed efficiently
2. **Prepared Statements**: Cached and reused for better performance
3. **Indexes**: Database indexes on frequently queried columns
4. **Lazy Loading**: Data loaded only when needed
5. **Caching**: Future enhancement for frequently accessed data

---

## Error Handling Strategy

```
Application Error → Service Layer → Log Error → User-Friendly Message
                         ↓
                    Try-Catch in DAO
                         ↓
                    Log to File (Log4j)
                         ↓
                    Return false/null
                         ↓
                    Service handles gracefully
                         ↓
                    Display error to user
```

---

This architecture ensures a robust, secure, maintainable, and scalable password management application.
