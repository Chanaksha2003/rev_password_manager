package com.revature.revpassword.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for EncryptionUtil
 */
class EncryptionUtilTest {

    @Test
    void testEncryptDecrypt() {
        String password = "MySecretPassword123!";
        String masterPassword = "MasterKey@2024";
        
        String encrypted = EncryptionUtil.encrypt(password, masterPassword);
        assertNotNull(encrypted);
        assertNotEquals(password, encrypted);
        
        String decrypted = EncryptionUtil.decrypt(encrypted, masterPassword);
        assertEquals(password, decrypted);
    }

    @Test
    void testEncryptProducesBase64() {
        String password = "TestPassword";
        String masterPassword = "MasterKey";
        
        String encrypted = EncryptionUtil.encrypt(password, masterPassword);
        
        // Base64 strings only contain alphanumeric characters, +, /, and =
        assertTrue(encrypted.matches("^[A-Za-z0-9+/=]+$"));
    }

    @Test
    void testDecryptWithWrongMasterPasswordThrowsException() {
        String password = "MySecretPassword123!";
        String correctMasterPassword = "CorrectMaster@2024";
        String wrongMasterPassword = "WrongMaster@2024";
        
        String encrypted = EncryptionUtil.encrypt(password, correctMasterPassword);
        
        assertThrows(RuntimeException.class, () -> {
            EncryptionUtil.decrypt(encrypted, wrongMasterPassword);
        });
    }

    @Test
    void testEncryptDifferentPasswordsProduceDifferentCiphertext() {
        String password1 = "Password1";
        String password2 = "Password2";
        String masterPassword = "MasterKey";
        
        String encrypted1 = EncryptionUtil.encrypt(password1, masterPassword);
        String encrypted2 = EncryptionUtil.encrypt(password2, masterPassword);
        
        assertNotEquals(encrypted1, encrypted2);
    }

    @Test
    void testEncryptWithSpecialCharacters() {
        String password = "P@$$w0rd!#$%^&*()";
        String masterPassword = "M@st3rK3y!";
        
        String encrypted = EncryptionUtil.encrypt(password, masterPassword);
        String decrypted = EncryptionUtil.decrypt(encrypted, masterPassword);
        
        assertEquals(password, decrypted);
    }

    @Test
    void testEncryptEmptyString() {
        String password = "";
        String masterPassword = "MasterKey";
        
        String encrypted = EncryptionUtil.encrypt(password, masterPassword);
        String decrypted = EncryptionUtil.decrypt(encrypted, masterPassword);
        
        assertEquals(password, decrypted);
    }

    @Test
    void testEncryptLongPassword() {
        String password = "ThisIsAVeryLongPasswordWithManyCharacters".repeat(10);
        String masterPassword = "MasterKey";
        
        String encrypted = EncryptionUtil.encrypt(password, masterPassword);
        String decrypted = EncryptionUtil.decrypt(encrypted, masterPassword);
        
        assertEquals(password, decrypted);
    }

    @Test
    void testEncryptWithUnicodeCharacters() {
        String password = "密码测试123!";
        String masterPassword = "MasterKey";
        
        String encrypted = EncryptionUtil.encrypt(password, masterPassword);
        String decrypted = EncryptionUtil.decrypt(encrypted, masterPassword);
        
        assertEquals(password, decrypted);
    }
}
