package com.revature.revpassword.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for PasswordGenerator
 */
class PasswordGeneratorTest {

    @Test
    void testGeneratePasswordWithAllCharacterTypes() {
        String password = PasswordGenerator.generatePassword(16, true, true, true, true);
        
        assertNotNull(password);
        assertEquals(16, password.length());
        assertTrue(containsUppercase(password));
        assertTrue(containsLowercase(password));
        assertTrue(containsDigit(password));
        assertTrue(containsSpecialChar(password));
    }

    @Test
    void testGeneratePasswordWithMinimumLength() {
        String password = PasswordGenerator.generatePassword(8, true, true, true, true);
        
        assertNotNull(password);
        assertEquals(8, password.length());
    }

    @Test
    void testGeneratePasswordThrowsExceptionForTooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            PasswordGenerator.generatePassword(3, true, true, true, true);
        });
    }

    @Test
    void testGeneratePasswordThrowsExceptionForNoCharacterTypes() {
        assertThrows(IllegalArgumentException.class, () -> {
            PasswordGenerator.generatePassword(10, false, false, false, false);
        });
    }

    @Test
    void testGeneratePasswordOnlyUppercase() {
        String password = PasswordGenerator.generatePassword(10, true, false, false, false);
        
        assertNotNull(password);
        assertEquals(10, password.length());
        assertTrue(password.chars().allMatch(Character::isUpperCase));
    }

    @Test
    void testGeneratePasswordOnlyLowercase() {
        String password = PasswordGenerator.generatePassword(10, false, true, false, false);
        
        assertNotNull(password);
        assertEquals(10, password.length());
        assertTrue(password.chars().allMatch(Character::isLowerCase));
    }

    @Test
    void testIsStrongPassword() {
        assertTrue(PasswordGenerator.isStrongPassword("Test@1234"));
        assertTrue(PasswordGenerator.isStrongPassword("MyP@ssw0rd"));
        assertFalse(PasswordGenerator.isStrongPassword("password"));
        assertFalse(PasswordGenerator.isStrongPassword("Pass123"));
        assertFalse(PasswordGenerator.isStrongPassword("Short1!"));
        assertFalse(PasswordGenerator.isStrongPassword(null));
    }

    @Test
    void testPasswordUniqueness() {
        String password1 = PasswordGenerator.generatePassword(16);
        String password2 = PasswordGenerator.generatePassword(16);
        
        assertNotEquals(password1, password2);
    }

    private boolean containsUppercase(String str) {
        return str.chars().anyMatch(Character::isUpperCase);
    }

    private boolean containsLowercase(String str) {
        return str.chars().anyMatch(Character::isLowerCase);
    }

    private boolean containsDigit(String str) {
        return str.chars().anyMatch(Character::isDigit);
    }

    private boolean containsSpecialChar(String str) {
        String specialChars = "!@#$%^&*()-_=+[]{}|;:,.<>?";
        return str.chars().anyMatch(c -> specialChars.indexOf(c) >= 0);
    }
}
