package com.revature.revpassword.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ValidationUtil
 */
class ValidationUtilTest {

    @Test
    void testIsValidEmail() {
        assertTrue(ValidationUtil.isValidEmail("test@example.com"));
        assertTrue(ValidationUtil.isValidEmail("user.name@example.co.uk"));
        assertTrue(ValidationUtil.isValidEmail("user+tag@example.com"));
        
        assertFalse(ValidationUtil.isValidEmail("invalid"));
        assertFalse(ValidationUtil.isValidEmail("@example.com"));
        assertFalse(ValidationUtil.isValidEmail("user@"));
        assertFalse(ValidationUtil.isValidEmail("user @example.com"));
        assertFalse(ValidationUtil.isValidEmail(null));
    }

    @Test
    void testIsValidUsername() {
        assertTrue(ValidationUtil.isValidUsername("user123"));
        assertTrue(ValidationUtil.isValidUsername("test_user"));
        assertTrue(ValidationUtil.isValidUsername("abc"));
        assertTrue(ValidationUtil.isValidUsername("user_name_123"));
        
        assertFalse(ValidationUtil.isValidUsername("ab")); // Too short
        assertFalse(ValidationUtil.isValidUsername("a".repeat(21))); // Too long
        assertFalse(ValidationUtil.isValidUsername("user name")); // Space
        assertFalse(ValidationUtil.isValidUsername("user-name")); // Hyphen
        assertFalse(ValidationUtil.isValidUsername("user@name")); // Special char
        assertFalse(ValidationUtil.isValidUsername(null));
    }

    @Test
    void testIsNotEmpty() {
        assertTrue(ValidationUtil.isNotEmpty("test"));
        assertTrue(ValidationUtil.isNotEmpty("  test  "));
        
        assertFalse(ValidationUtil.isNotEmpty(""));
        assertFalse(ValidationUtil.isNotEmpty("   "));
        assertFalse(ValidationUtil.isNotEmpty(null));
    }

    @Test
    void testIsValidPassword() {
        assertTrue(ValidationUtil.isValidPassword("Test@1234"));
        assertTrue(ValidationUtil.isValidPassword("MyP@ssw0rd"));
        assertTrue(ValidationUtil.isValidPassword("Secure#Pass123"));
        
        assertFalse(ValidationUtil.isValidPassword("short")); // Too short
        assertFalse(ValidationUtil.isValidPassword("nouppercaseorspecial123")); // No uppercase/special
        assertFalse(ValidationUtil.isValidPassword("NOLOWERCASE123!")); // No lowercase
        assertFalse(ValidationUtil.isValidPassword("NoDigitsHere!")); // No digits
        assertFalse(ValidationUtil.isValidPassword("NoSpecial123")); // No special chars
        assertFalse(ValidationUtil.isValidPassword(null));
    }

    @Test
    void testGetPasswordStrengthMessage() {
        String message = ValidationUtil.getPasswordStrengthMessage();
        
        assertNotNull(message);
        assertTrue(message.contains("8 characters"));
        assertTrue(message.contains("uppercase"));
        assertTrue(message.contains("lowercase"));
        assertTrue(message.contains("digit"));
        assertTrue(message.contains("special character"));
    }
}
