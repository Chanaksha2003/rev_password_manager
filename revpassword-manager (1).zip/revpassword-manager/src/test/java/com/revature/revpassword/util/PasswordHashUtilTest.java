package com.revature.revpassword.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for PasswordHashUtil
 */
class PasswordHashUtilTest {

    @Test
    void testHashPassword() {
        String password = "TestPassword123!";
        String hash = PasswordHashUtil.hashPassword(password);
        
        assertNotNull(hash);
        assertNotEquals(password, hash);
        assertTrue(hash.startsWith("$2a$"));
    }

    @Test
    void testHashPasswordUniqueness() {
        String password = "TestPassword123!";
        String hash1 = PasswordHashUtil.hashPassword(password);
        String hash2 = PasswordHashUtil.hashPassword(password);
        
        assertNotNull(hash1);
        assertNotNull(hash2);
        assertNotEquals(hash1, hash2); // BCrypt generates unique salts
    }

    @Test
    void testVerifyPassword() {
        String password = "TestPassword123!";
        String hash = PasswordHashUtil.hashPassword(password);
        
        assertTrue(PasswordHashUtil.verifyPassword(password, hash));
    }

    @Test
    void testVerifyPasswordFailsWithWrongPassword() {
        String password = "TestPassword123!";
        String wrongPassword = "WrongPassword456!";
        String hash = PasswordHashUtil.hashPassword(password);
        
        assertFalse(PasswordHashUtil.verifyPassword(wrongPassword, hash));
    }

    @Test
    void testVerifyPasswordWithEmptyPassword() {
        String hash = PasswordHashUtil.hashPassword("test");
        assertFalse(PasswordHashUtil.verifyPassword("", hash));
    }

    @Test
    void testHashPasswordWithSpecialCharacters() {
        String password = "P@$$w0rd!#$%";
        String hash = PasswordHashUtil.hashPassword(password);
        
        assertTrue(PasswordHashUtil.verifyPassword(password, hash));
    }

    @Test
    void testHashPasswordWithUnicode() {
        String password = "Test密码123!";
        String hash = PasswordHashUtil.hashPassword(password);
        
        assertTrue(PasswordHashUtil.verifyPassword(password, hash));
    }
}
