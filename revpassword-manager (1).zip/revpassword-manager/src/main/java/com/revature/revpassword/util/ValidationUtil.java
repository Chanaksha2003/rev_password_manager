package com.revature.revpassword.util;

import java.util.regex.Pattern;

/**
 * Utility class for validating user inputs
 */
public class ValidationUtil {
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{3,20}$");

    /**
     * Validate email format
     */
    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    /**
     * Validate username format
     */
    public static boolean isValidUsername(String username) {
        return username != null && USERNAME_PATTERN.matcher(username).matches();
    }

    /**
     * Validate that string is not empty
     */
    public static boolean isNotEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }

    /**
     * Validate password strength
     */
    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        return PasswordGenerator.isStrongPassword(password);
    }

    /**
     * Get password strength message
     */
    public static String getPasswordStrengthMessage() {
        return "Password must be at least 8 characters long and contain:\n" +
               "- At least one uppercase letter\n" +
               "- At least one lowercase letter\n" +
               "- At least one digit\n" +
               "- At least one special character (!@#$%^&*()-_=+[]{}|;:,.<>?)";
    }
}
