package com.revature.revpassword.util;

import at.favre.lib.crypto.bcrypt.BCrypt;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Utility class for hashing and verifying passwords using BCrypt
 */
public class PasswordHashUtil {
    private static final Logger logger = LogManager.getLogger(PasswordHashUtil.class);
    private static final int BCRYPT_COST = 12;

    /**
     * Hash a password using BCrypt
     */
    public static String hashPassword(String password) {
        try {
            String hashed = BCrypt.withDefaults().hashToString(BCRYPT_COST, password.toCharArray());
            logger.debug("Password hashed successfully");
            return hashed;
        } catch (Exception e) {
            logger.error("Error hashing password: {}", e.getMessage());
            throw new RuntimeException("Password hashing failed", e);
        }
    }

    /**
     * Verify a password against its hash
     */
    public static boolean verifyPassword(String password, String hashedPassword) {
        try {
            BCrypt.Result result = BCrypt.verifyer().verify(password.toCharArray(), hashedPassword);
            boolean isValid = result.verified;
            logger.debug("Password verification result: {}", isValid);
            return isValid;
        } catch (Exception e) {
            logger.error("Error verifying password: {}", e.getMessage());
            return false;
        }
    }
}
