package com.revature.revpassword.controller;

import com.revature.revpassword.model.PasswordEntry;
import com.revature.revpassword.model.SecurityQuestion;
import com.revature.revpassword.model.User;
import com.revature.revpassword.service.PasswordVaultService;
import com.revature.revpassword.service.SecurityService;
import com.revature.revpassword.service.UserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

/**
 * Main controller for console-based user interface
 */
public class MainController {
    private static final Logger logger = LogManager.getLogger(MainController.class);
    private final Scanner scanner;
    private final UserService userService;
    private final PasswordVaultService vaultService;
    private final SecurityService securityService;
    private User currentUser;
    private String currentMasterPassword;

    public MainController() {
        this.scanner = new Scanner(System.in);
        this.userService = new UserService();
        this.vaultService = new PasswordVaultService();
        this.securityService = new SecurityService();
    }

    /**
     * Start the application
     */
    public void start() {
        logger.info("RevPassword Manager started");
        System.out.println("===========================================");
        System.out.println("   Welcome to RevPassword Manager");
        System.out.println("===========================================\n");

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                running = showMainMenu();
            } else {
                showUserMenu();
            }
        }

        scanner.close();
        logger.info("Application closed");
    }

    /**
     * Show main menu for non-authenticated users
     */
    private boolean showMainMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Register");
        System.out.println("2. Login");
        System.out.println("3. Forgot Password");
        System.out.println("4. Exit");
        System.out.print("Choose an option: ");

        int choice = getIntInput();

        switch (choice) {
            case 1:
                handleRegistration();
                break;
            case 2:
                handleLogin();
                break;
            case 3:
                handleForgotPassword();
                break;
            case 4:
                System.out.println("Thank you for using RevPassword Manager. Goodbye!");
                return false;
            default:
                System.out.println("Invalid option. Please try again.");
        }

        return true;
    }

    /**
     * Show user menu for authenticated users
     */
    private void showUserMenu() {
        System.out.println("\n--- User Menu ---");
        System.out.println("Logged in as: " + currentUser.getUsername());
        System.out.println("1. List All Passwords");
        System.out.println("2. View Password Details");
        System.out.println("3. Add New Password");
        System.out.println("4. Update Password");
        System.out.println("5. Delete Password");
        System.out.println("6. Search Passwords");
        System.out.println("7. Generate Random Password");
        System.out.println("8. Manage Security Questions");
        System.out.println("9. Update Profile");
        System.out.println("10. Change Master Password");
        System.out.println("11. Logout");
        System.out.print("Choose an option: ");

        int choice = getIntInput();

        switch (choice) {
            case 1:
                listAllPasswords();
                break;
            case 2:
                viewPasswordDetails();
                break;
            case 3:
                addNewPassword();
                break;
            case 4:
                updatePassword();
                break;
            case 5:
                deletePassword();
                break;
            case 6:
                searchPasswords();
                break;
            case 7:
                generateRandomPassword();
                break;
            case 8:
                manageSecurityQuestions();
                break;
            case 9:
                updateProfile();
                break;
            case 10:
                changeMasterPassword();
                break;
            case 11:
                logout();
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    /**
     * Handle user registration
     */
    private void handleRegistration() {
        System.out.println("\n--- User Registration ---");
        
        System.out.print("Enter username (3-20 alphanumeric characters): ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter email: ");
        String email = scanner.nextLine().trim();

        System.out.print("Enter full name: ");
        String fullName = scanner.nextLine().trim();

        System.out.print("Enter master password: ");
        String masterPassword = scanner.nextLine();

        System.out.print("Confirm master password: ");
        String confirmPassword = scanner.nextLine();

        if (!masterPassword.equals(confirmPassword)) {
            System.out.println("Passwords do not match. Registration failed.");
            return;
        }

        boolean success = userService.registerUser(username, email, fullName, masterPassword);
        
        if (success) {
            System.out.println("\nWould you like to set up security questions now? (y/n): ");
            String response = scanner.nextLine().trim().toLowerCase();
            if (response.equals("y")) {
                // Login first to set up security questions
                Optional<User> userOpt = userService.login(username, masterPassword);
                if (userOpt.isPresent()) {
                    currentUser = userOpt.get();
                    currentMasterPassword = masterPassword;
                    setupSecurityQuestions();
                    logout();
                }
            }
        }
    }

    /**
     * Handle user login
     */
    private void handleLogin() {
        System.out.println("\n--- User Login ---");
        
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter master password: ");
        String masterPassword = scanner.nextLine();

        Optional<User> userOpt = userService.login(username, masterPassword);

        if (userOpt.isPresent()) {
            currentUser = userOpt.get();
            currentMasterPassword = masterPassword;
            System.out.println("\nLogin successful! Welcome, " + currentUser.getFullName() + "!");
            
            int passwordCount = vaultService.getPasswordCount(currentUser.getUserId());
            System.out.println("You have " + passwordCount + " passwords stored in your vault.");
        }
    }

    /**
     * Handle forgot password
     */
    private void handleForgotPassword() {
        System.out.println("\n--- Password Recovery ---");
        
        System.out.print("Enter your username: ");
        String username = scanner.nextLine().trim();

        boolean initiated = userService.recoverPassword(username);

        if (!initiated) {
            return;
        }

        Optional<User> userOpt = userService.getUserByUsername(username);
        if (userOpt.isEmpty()) {
            return;
        }

        User user = userOpt.get();
        List<SecurityQuestion> questions = securityService.getSecurityQuestions(user.getUserId());

        if (questions.isEmpty()) {
            System.out.println("No security questions found. Please contact support.");
            return;
        }

        System.out.println("\nPlease answer the following security questions:");

        int correctAnswers = 0;
        for (SecurityQuestion question : questions) {
            System.out.println("\nQuestion: " + question.getQuestion());
            System.out.print("Your answer: ");
            String answer = scanner.nextLine().trim();

            if (securityService.verifySecurityAnswer(question.getQuestionId(), answer)) {
                correctAnswers++;
            }
        }

        if (correctAnswers == questions.size()) {
            System.out.println("\nSecurity questions verified! You can now reset your password.");
            
            System.out.print("Enter new master password: ");
            String newPassword = scanner.nextLine();

            System.out.print("Confirm new master password: ");
            String confirmPassword = scanner.nextLine();

            if (!newPassword.equals(confirmPassword)) {
                System.out.println("Passwords do not match. Password reset failed.");
                return;
            }

            // In a real implementation, you would update the password here
            System.out.println("Password reset functionality would be completed here.");
        } else {
            System.out.println("\nSecurity verification failed. Cannot reset password.");
        }
    }

    /**
     * List all passwords
     */
    private void listAllPasswords() {
        System.out.println("\n--- Password Vault ---");
        
        List<PasswordEntry> passwords = vaultService.getAllPasswords(currentUser.getUserId());

        if (passwords.isEmpty()) {
            System.out.println("No passwords stored yet.");
            return;
        }

        System.out.println("\n" + String.format("%-5s %-25s %-25s %-30s", "ID", "Account Name", "Username", "Website"));
        System.out.println("=".repeat(90));

        for (PasswordEntry entry : passwords) {
            System.out.println(String.format("%-5d %-25s %-25s %-30s", 
                entry.getVaultId(),
                truncate(entry.getAccountName(), 25),
                truncate(entry.getUsername() != null ? entry.getUsername() : "N/A", 25),
                truncate(entry.getWebsiteUrl() != null ? entry.getWebsiteUrl() : "N/A", 30)
            ));
        }
    }

    /**
     * View password details with decryption
     */
    private void viewPasswordDetails() {
        System.out.println("\n--- View Password Details ---");
        
        System.out.print("Enter password entry ID: ");
        int vaultId = getIntInput();

        Optional<PasswordEntry> entryOpt = vaultService.getPasswordEntry(vaultId);

        if (entryOpt.isEmpty()) {
            System.out.println("Password entry not found.");
            return;
        }

        PasswordEntry entry = entryOpt.get();

        if (entry.getUserId() != currentUser.getUserId()) {
            System.out.println("Access denied. This entry belongs to another user.");
            return;
        }

        // Re-verify master password for security
        System.out.print("Re-enter your master password: ");
        String masterPassword = scanner.nextLine();

        Optional<String> decryptedPasswordOpt = vaultService.getDecryptedPassword(vaultId, masterPassword);

        if (decryptedPasswordOpt.isEmpty()) {
            return;
        }

        System.out.println("\n--- Password Details ---");
        System.out.println("Account Name: " + entry.getAccountName());
        System.out.println("Username: " + (entry.getUsername() != null ? entry.getUsername() : "N/A"));
        System.out.println("Password: " + decryptedPasswordOpt.get());
        System.out.println("Website URL: " + (entry.getWebsiteUrl() != null ? entry.getWebsiteUrl() : "N/A"));
        System.out.println("Notes: " + (entry.getNotes() != null ? entry.getNotes() : "N/A"));
        System.out.println("Created: " + entry.getCreatedAt());
        System.out.println("Last Updated: " + entry.getUpdatedAt());
    }

    /**
     * Add new password
     */
    private void addNewPassword() {
        System.out.println("\n--- Add New Password ---");
        
        System.out.print("Enter account name: ");
        String accountName = scanner.nextLine().trim();

        System.out.print("Enter username (optional): ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter password (or press Enter to generate one): ");
        String password = scanner.nextLine();

        if (password.trim().isEmpty()) {
            System.out.println("\nGenerating a strong password...");
            password = vaultService.generateStrongPassword(16, true, true, true, true);
            System.out.println("Generated password: " + password);
            System.out.print("Use this password? (y/n): ");
            String use = scanner.nextLine().trim().toLowerCase();
            if (!use.equals("y")) {
                System.out.print("Enter your own password: ");
                password = scanner.nextLine();
            }
        }

        System.out.print("Enter website URL (optional): ");
        String websiteUrl = scanner.nextLine().trim();

        System.out.print("Enter notes (optional): ");
        String notes = scanner.nextLine().trim();

        boolean success = vaultService.addPassword(currentUser.getUserId(), accountName, username, 
                                                   password, websiteUrl, notes, currentMasterPassword);

        if (success) {
            logger.info("Password added successfully for account: {}", accountName);
        }
    }

    /**
     * Update password
     */
    private void updatePassword() {
        System.out.println("\n--- Update Password ---");
        
        System.out.print("Enter password entry ID to update: ");
        int vaultId = getIntInput();

        Optional<PasswordEntry> entryOpt = vaultService.getPasswordEntry(vaultId);

        if (entryOpt.isEmpty() || entryOpt.get().getUserId() != currentUser.getUserId()) {
            System.out.println("Password entry not found or access denied.");
            return;
        }

        PasswordEntry entry = entryOpt.get();
        System.out.println("\nCurrent account name: " + entry.getAccountName());

        System.out.print("Enter new account name (or press Enter to keep current): ");
        String accountName = scanner.nextLine().trim();

        System.out.print("Enter new username (or press Enter to keep current): ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter new password (or press Enter to keep current): ");
        String password = scanner.nextLine();

        System.out.print("Enter new website URL (or press Enter to keep current): ");
        String websiteUrl = scanner.nextLine().trim();

        System.out.print("Enter new notes (or press Enter to keep current): ");
        String notes = scanner.nextLine().trim();

        boolean success = vaultService.updatePassword(vaultId, 
            accountName.isEmpty() ? null : accountName,
            username.isEmpty() ? null : username,
            password.isEmpty() ? null : password,
            websiteUrl.isEmpty() ? null : websiteUrl,
            notes.isEmpty() ? null : notes,
            currentMasterPassword);

        if (success) {
            logger.info("Password updated successfully for vault ID: {}", vaultId);
        }
    }

    /**
     * Delete password
     */
    private void deletePassword() {
        System.out.println("\n--- Delete Password ---");
        
        System.out.print("Enter password entry ID to delete: ");
        int vaultId = getIntInput();

        Optional<PasswordEntry> entryOpt = vaultService.getPasswordEntry(vaultId);

        if (entryOpt.isEmpty() || entryOpt.get().getUserId() != currentUser.getUserId()) {
            System.out.println("Password entry not found or access denied.");
            return;
        }

        System.out.print("Are you sure you want to delete this entry? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();

        if (confirm.equals("yes")) {
            boolean success = vaultService.deletePassword(vaultId);
            if (success) {
                logger.info("Password deleted for vault ID: {}", vaultId);
            }
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    /**
     * Search passwords
     */
    private void searchPasswords() {
        System.out.println("\n--- Search Passwords ---");
        
        System.out.print("Enter search term (account name): ");
        String searchTerm = scanner.nextLine().trim();

        List<PasswordEntry> results = vaultService.searchPasswords(currentUser.getUserId(), searchTerm);

        if (results.isEmpty()) {
            System.out.println("No passwords found matching '" + searchTerm + "'.");
            return;
        }

        System.out.println("\nSearch Results:");
        System.out.println(String.format("%-5s %-25s %-25s %-30s", "ID", "Account Name", "Username", "Website"));
        System.out.println("=".repeat(90));

        for (PasswordEntry entry : results) {
            System.out.println(String.format("%-5d %-25s %-25s %-30s", 
                entry.getVaultId(),
                truncate(entry.getAccountName(), 25),
                truncate(entry.getUsername() != null ? entry.getUsername() : "N/A", 25),
                truncate(entry.getWebsiteUrl() != null ? entry.getWebsiteUrl() : "N/A", 30)
            ));
        }
    }

    /**
     * Generate random password
     */
    private void generateRandomPassword() {
        System.out.println("\n--- Generate Random Password ---");
        
        System.out.print("Enter password length (8-32): ");
        int length = getIntInput();

        if (length < 8 || length > 32) {
            System.out.println("Invalid length. Please enter a value between 8 and 32.");
            return;
        }

        System.out.print("Include uppercase letters? (y/n): ");
        boolean uppercase = scanner.nextLine().trim().toLowerCase().equals("y");

        System.out.print("Include lowercase letters? (y/n): ");
        boolean lowercase = scanner.nextLine().trim().toLowerCase().equals("y");

        System.out.print("Include digits? (y/n): ");
        boolean digits = scanner.nextLine().trim().toLowerCase().equals("y");

        System.out.print("Include special characters? (y/n): ");
        boolean special = scanner.nextLine().trim().toLowerCase().equals("y");

        String password = vaultService.generateStrongPassword(length, uppercase, lowercase, digits, special);

        if (password != null) {
            System.out.println("\nGenerated Password: " + password);
            System.out.println("\nNote: Make sure to copy this password if you want to use it!");
        }
    }

    /**
     * Manage security questions
     */
    private void manageSecurityQuestions() {
        System.out.println("\n--- Manage Security Questions ---");
        System.out.println("1. View Security Questions");
        System.out.println("2. Add Security Question");
        System.out.println("3. Delete Security Question");
        System.out.println("4. Back");
        System.out.print("Choose an option: ");

        int choice = getIntInput();

        switch (choice) {
            case 1:
                viewSecurityQuestions();
                break;
            case 2:
                addSecurityQuestion();
                break;
            case 3:
                deleteSecurityQuestion();
                break;
            case 4:
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    /**
     * View security questions
     */
    private void viewSecurityQuestions() {
        List<SecurityQuestion> questions = securityService.getSecurityQuestions(currentUser.getUserId());

        if (questions.isEmpty()) {
            System.out.println("No security questions set up yet.");
            return;
        }

        System.out.println("\n--- Your Security Questions ---");
        for (int i = 0; i < questions.size(); i++) {
            System.out.println((i + 1) + ". " + questions.get(i).getQuestion() + 
                             " (ID: " + questions.get(i).getQuestionId() + ")");
        }
    }

    /**
     * Add security question
     */
    private void addSecurityQuestion() {
        System.out.println("\n--- Add Security Question ---");
        
        System.out.print("Enter your security question: ");
        String question = scanner.nextLine().trim();

        System.out.print("Enter the answer: ");
        String answer = scanner.nextLine().trim();

        securityService.addSecurityQuestion(currentUser.getUserId(), question, answer);
    }

    /**
     * Delete security question
     */
    private void deleteSecurityQuestion() {
        viewSecurityQuestions();
        
        System.out.print("\nEnter question ID to delete: ");
        int questionId = getIntInput();

        System.out.print("Are you sure? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();

        if (confirm.equals("yes")) {
            securityService.deleteSecurityQuestion(questionId);
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    /**
     * Setup security questions during registration
     */
    private void setupSecurityQuestions() {
        System.out.println("\n--- Setup Security Questions ---");
        System.out.println("Please set up at least 2 security questions for account recovery.");

        for (int i = 1; i <= 2; i++) {
            System.out.println("\nQuestion " + i + ":");
            System.out.print("Enter your security question: ");
            String question = scanner.nextLine().trim();

            System.out.print("Enter the answer: ");
            String answer = scanner.nextLine().trim();

            securityService.addSecurityQuestion(currentUser.getUserId(), question, answer);
        }

        System.out.println("\nSecurity questions setup complete!");
    }

    /**
     * Update profile
     */
    private void updateProfile() {
        System.out.println("\n--- Update Profile ---");
        System.out.println("Current email: " + currentUser.getEmail());
        System.out.println("Current full name: " + currentUser.getFullName());

        System.out.print("\nEnter new email (or press Enter to keep current): ");
        String email = scanner.nextLine().trim();

        System.out.print("Enter new full name (or press Enter to keep current): ");
        String fullName = scanner.nextLine().trim();

        if (email.isEmpty() && fullName.isEmpty()) {
            System.out.println("No changes made.");
            return;
        }

        boolean success = userService.updateProfile(currentUser.getUserId(), 
            email.isEmpty() ? currentUser.getEmail() : email,
            fullName.isEmpty() ? currentUser.getFullName() : fullName);

        if (success) {
            // Refresh user data
            Optional<User> updatedUser = userService.getUserById(currentUser.getUserId());
            updatedUser.ifPresent(user -> currentUser = user);
        }
    }

    /**
     * Change master password
     */
    private void changeMasterPassword() {
        System.out.println("\n--- Change Master Password ---");
        
        System.out.print("Enter current master password: ");
        String oldPassword = scanner.nextLine();

        System.out.print("Enter new master password: ");
        String newPassword = scanner.nextLine();

        System.out.print("Confirm new master password: ");
        String confirmPassword = scanner.nextLine();

        if (!newPassword.equals(confirmPassword)) {
            System.out.println("Passwords do not match.");
            return;
        }

        boolean success = userService.changeMasterPassword(currentUser.getUserId(), oldPassword, newPassword);

        if (success) {
            currentMasterPassword = newPassword;
            System.out.println("\nIMPORTANT: All your stored passwords are encrypted with your master password.");
            System.out.println("Make sure to remember your new master password!");
        }
    }

    /**
     * Logout
     */
    private void logout() {
        currentUser = null;
        currentMasterPassword = null;
        System.out.println("\nLogged out successfully!");
        logger.info("User logged out");
    }

    /**
     * Get integer input with error handling
     */
    private int getIntInput() {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a number: ");
            }
        }
    }

    /**
     * Truncate string to specified length
     */
    private String truncate(String str, int length) {
        if (str == null) return "";
        return str.length() > length ? str.substring(0, length - 3) + "..." : str;
    }
}
