package com.revature.revpassword;

import com.revature.revpassword.controller.MainController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Main Application Entry Point
 * RevPassword Manager - A secure password management application
 */
public class MainApplication {
    private static final Logger logger = LogManager.getLogger(MainApplication.class);

    public static void main(String[] args) {
        try {
            logger.info("Starting RevPassword Manager Application");
            
            MainController controller = new MainController();
            controller.start();
            
            logger.info("RevPassword Manager Application terminated");
        } catch (Exception e) {
            logger.error("Fatal error in application: {}", e.getMessage(), e);
            System.err.println("A fatal error occurred. Please check the logs for details.");
        }
    }
}
