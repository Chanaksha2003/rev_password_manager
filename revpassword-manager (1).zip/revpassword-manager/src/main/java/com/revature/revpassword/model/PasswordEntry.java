package com.revature.revpassword.model;

import java.sql.Timestamp;
import java.util.Objects;

/**
 * PasswordEntry entity representing a password stored in the vault
 */
public class PasswordEntry {
    private int vaultId;
    private int userId;
    private String accountName;
    private String username;
    private String encryptedPassword;
    private String websiteUrl;
    private String notes;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Constructors
    public PasswordEntry() {
    }

    public PasswordEntry(int userId, String accountName, String username, String encryptedPassword) {
        this.userId = userId;
        this.accountName = accountName;
        this.username = username;
        this.encryptedPassword = encryptedPassword;
    }

    public PasswordEntry(int userId, String accountName, String username, String encryptedPassword, 
                        String websiteUrl, String notes) {
        this.userId = userId;
        this.accountName = accountName;
        this.username = username;
        this.encryptedPassword = encryptedPassword;
        this.websiteUrl = websiteUrl;
        this.notes = notes;
    }

    public PasswordEntry(int vaultId, int userId, String accountName, String username, 
                        String encryptedPassword, String websiteUrl, String notes, 
                        Timestamp createdAt, Timestamp updatedAt) {
        this.vaultId = vaultId;
        this.userId = userId;
        this.accountName = accountName;
        this.username = username;
        this.encryptedPassword = encryptedPassword;
        this.websiteUrl = websiteUrl;
        this.notes = notes;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public int getVaultId() {
        return vaultId;
    }

    public void setVaultId(int vaultId) {
        this.vaultId = vaultId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEncryptedPassword() {
        return encryptedPassword;
    }

    public void setEncryptedPassword(String encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PasswordEntry that = (PasswordEntry) o;
        return vaultId == that.vaultId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(vaultId);
    }

    @Override
    public String toString() {
        return "PasswordEntry{" +
                "vaultId=" + vaultId +
                ", userId=" + userId +
                ", accountName='" + accountName + '\'' +
                ", username='" + username + '\'' +
                ", websiteUrl='" + websiteUrl + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
