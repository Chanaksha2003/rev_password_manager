package com.revature.revpassword.dao;

import com.revature.revpassword.model.VerificationCode;
import com.revature.revpassword.util.DatabaseConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.Optional;

/**
 * Data Access Object for Verification Codes
 */
public class VerificationCodeDAO {
    private static final Logger logger = LogManager.getLogger(VerificationCodeDAO.class);
    private final DatabaseConnection dbConnection;

    public VerificationCodeDAO() {
        this.dbConnection = DatabaseConnection.getInstance();
    }

    /**
     * Create a new verification code
     */
    public boolean createVerificationCode(VerificationCode code) {
        String sql = "INSERT INTO verification_codes (user_id, verification_code, purpose, expires_at) " +
                     "VALUES (?, ?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, code.getUserId());
            pstmt.setString(2, code.getVerificationCode());
            pstmt.setString(3, code.getPurpose());
            pstmt.setTimestamp(4, code.getExpiresAt());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        code.setCodeId(generatedKeys.getInt(1));
                    }
                }
                logger.info("Verification code created for user ID: {} with purpose: {}", 
                           code.getUserId(), code.getPurpose());
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error creating verification code: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Find valid (not expired and not used) verification code
     */
    public Optional<VerificationCode> findValidCode(int userId, String code, String purpose) {
        String sql = "SELECT * FROM verification_codes WHERE user_id = ? AND verification_code = ? " +
                     "AND purpose = ? AND is_used = FALSE AND expires_at > CURRENT_TIMESTAMP";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.setString(2, code);
            pstmt.setString(3, purpose);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                VerificationCode verificationCode = extractVerificationCodeFromResultSet(rs);
                logger.debug("Valid verification code found for user ID: {}", userId);
                return Optional.of(verificationCode);
            }
        } catch (SQLException e) {
            logger.error("Error finding verification code: {}", e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Mark verification code as used
     */
    public boolean markCodeAsUsed(int codeId) {
        String sql = "UPDATE verification_codes SET is_used = TRUE WHERE code_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, codeId);
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                logger.info("Verification code marked as used: {}", codeId);
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error marking code as used: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Delete expired verification codes
     */
    public int deleteExpiredCodes() {
        String sql = "DELETE FROM verification_codes WHERE expires_at < CURRENT_TIMESTAMP";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            int deletedRows = pstmt.executeUpdate();
            logger.info("Deleted {} expired verification codes", deletedRows);
            return deletedRows;
        } catch (SQLException e) {
            logger.error("Error deleting expired codes: {}", e.getMessage());
        }
        return 0;
    }

    /**
     * Delete all verification codes for a user
     */
    public boolean deleteUserCodes(int userId) {
        String sql = "DELETE FROM verification_codes WHERE user_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            int affectedRows = pstmt.executeUpdate();
            logger.info("Deleted {} verification codes for user ID: {}", affectedRows, userId);
            return true;
        } catch (SQLException e) {
            logger.error("Error deleting user codes: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Extract VerificationCode object from ResultSet
     */
    private VerificationCode extractVerificationCodeFromResultSet(ResultSet rs) throws SQLException {
        return new VerificationCode(
            rs.getInt("code_id"),
            rs.getInt("user_id"),
            rs.getString("verification_code"),
            rs.getString("purpose"),
            rs.getTimestamp("created_at"),
            rs.getTimestamp("expires_at"),
            rs.getBoolean("is_used")
        );
    }
}
