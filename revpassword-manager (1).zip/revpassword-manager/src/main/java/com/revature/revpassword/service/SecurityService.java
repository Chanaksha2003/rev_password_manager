package com.revature.revpassword.service;

import com.revature.revpassword.dao.SecurityQuestionDAO;
import com.revature.revpassword.dao.VerificationCodeDAO;
import com.revature.revpassword.model.SecurityQuestion;
import com.revature.revpassword.model.VerificationCode;
import com.revature.revpassword.util.PasswordHashUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Service layer for Security operations
 */
public class SecurityService {
    private static final Logger logger = LogManager.getLogger(SecurityService.class);
    private final SecurityQuestionDAO securityQuestionDAO;
    private final VerificationCodeDAO verificationCodeDAO;
    private final Random random;

    public SecurityService() {
        this.securityQuestionDAO = new SecurityQuestionDAO();
        this.verificationCodeDAO = new VerificationCodeDAO();
        this.random = new Random();
    }

    /**
     * Add security question
     */
    public boolean addSecurityQuestion(int userId, String question, String answer) {
        if (question == null || question.trim().isEmpty() || 
            answer == null || answer.trim().isEmpty()) {
            logger.warn("Invalid security question or answer provided");
            System.out.println("Question and answer cannot be empty.");
            return false;
        }

        // Hash the answer for security
        String answerHash = PasswordHashUtil.hashPassword(answer.toLowerCase().trim());

        SecurityQuestion securityQuestion = new SecurityQuestion(userId, question, answerHash);
        boolean added = securityQuestionDAO.addSecurityQuestion(securityQuestion);

        if (added) {
            logger.info("Security question added for user ID: {}", userId);
            System.out.println("Security question added successfully!");
        } else {
            logger.error("Failed to add security question for user ID: {}", userId);
            System.out.println("Failed to add security question. Please try again.");
        }

        return added;
    }

    /**
     * Get all security questions for a user
     */
    public List<SecurityQuestion> getSecurityQuestions(int userId) {
        List<SecurityQuestion> questions = securityQuestionDAO.getSecurityQuestionsByUserId(userId);
        logger.debug("Retrieved {} security questions for user ID: {}", questions.size(), userId);
        return questions;
    }

    /**
     * Verify security question answer
     */
    public boolean verifySecurityAnswer(int questionId, String answer) {
        Optional<SecurityQuestion> questionOpt = securityQuestionDAO.getSecurityQuestionById(questionId);

        if (questionOpt.isEmpty()) {
            logger.warn("Security question not found: {}", questionId);
            return false;
        }

        SecurityQuestion question = questionOpt.get();
        boolean verified = PasswordHashUtil.verifyPassword(answer.toLowerCase().trim(), 
                                                          question.getAnswerHash());

        if (verified) {
            logger.debug("Security answer verified for question ID: {}", questionId);
        } else {
            logger.warn("Incorrect security answer for question ID: {}", questionId);
        }

        return verified;
    }

    /**
     * Update security question
     */
    public boolean updateSecurityQuestion(int questionId, String newQuestion, String newAnswer) {
        Optional<SecurityQuestion> questionOpt = securityQuestionDAO.getSecurityQuestionById(questionId);

        if (questionOpt.isEmpty()) {
            logger.warn("Security question not found for update: {}", questionId);
            System.out.println("Security question not found.");
            return false;
        }

        SecurityQuestion question = questionOpt.get();
        
        if (newQuestion != null && !newQuestion.trim().isEmpty()) {
            question.setQuestion(newQuestion);
        }
        
        if (newAnswer != null && !newAnswer.trim().isEmpty()) {
            String answerHash = PasswordHashUtil.hashPassword(newAnswer.toLowerCase().trim());
            question.setAnswerHash(answerHash);
        }

        boolean updated = securityQuestionDAO.updateSecurityQuestion(question);

        if (updated) {
            logger.info("Security question updated: {}", questionId);
            System.out.println("Security question updated successfully!");
        } else {
            logger.error("Failed to update security question: {}", questionId);
            System.out.println("Failed to update security question. Please try again.");
        }

        return updated;
    }

    /**
     * Delete security question
     */
    public boolean deleteSecurityQuestion(int questionId) {
        boolean deleted = securityQuestionDAO.deleteSecurityQuestion(questionId);

        if (deleted) {
            logger.info("Security question deleted: {}", questionId);
            System.out.println("Security question deleted successfully!");
        } else {
            logger.error("Failed to delete security question: {}", questionId);
            System.out.println("Failed to delete security question. Please try again.");
        }

        return deleted;
    }

    /**
     * Generate verification code
     */
    public String generateVerificationCode(int userId, String purpose, int expiryMinutes) {
        // Generate 6-digit code
        String code = String.format("%06d", random.nextInt(1000000));

        // Calculate expiry time
        long expiryTime = System.currentTimeMillis() + (expiryMinutes * 60 * 1000);
        Timestamp expiresAt = new Timestamp(expiryTime);

        // Create verification code
        VerificationCode verificationCode = new VerificationCode(userId, code, purpose, expiresAt);
        boolean created = verificationCodeDAO.createVerificationCode(verificationCode);

        if (created) {
            logger.info("Verification code generated for user ID: {} with purpose: {}", userId, purpose);
            System.out.println("Verification code generated: " + code);
            System.out.println("This code will expire in " + expiryMinutes + " minutes.");
            return code;
        } else {
            logger.error("Failed to generate verification code for user ID: {}", userId);
            System.out.println("Failed to generate verification code. Please try again.");
            return null;
        }
    }

    /**
     * Verify and use verification code
     */
    public boolean verifyAndUseCode(int userId, String code, String purpose) {
        Optional<VerificationCode> codeOpt = verificationCodeDAO.findValidCode(userId, code, purpose);

        if (codeOpt.isEmpty()) {
            logger.warn("Invalid or expired verification code for user ID: {}", userId);
            System.out.println("Invalid or expired verification code.");
            return false;
        }

        VerificationCode verificationCode = codeOpt.get();
        boolean marked = verificationCodeDAO.markCodeAsUsed(verificationCode.getCodeId());

        if (marked) {
            logger.info("Verification code verified and marked as used for user ID: {}", userId);
            return true;
        } else {
            logger.error("Failed to mark verification code as used");
            return false;
        }
    }

    /**
     * Clean up expired verification codes
     */
    public void cleanupExpiredCodes() {
        int deleted = verificationCodeDAO.deleteExpiredCodes();
        logger.info("Cleaned up {} expired verification codes", deleted);
    }
}
