package com.revature.revpassword.model;

import java.sql.Timestamp;
import java.util.Objects;

/**
 * SecurityQuestion entity for account recovery
 */
public class SecurityQuestion {
    private int questionId;
    private int userId;
    private String question;
    private String answerHash;
    private Timestamp createdAt;

    // Constructors
    public SecurityQuestion() {
    }

    public SecurityQuestion(int userId, String question, String answerHash) {
        this.userId = userId;
        this.question = question;
        this.answerHash = answerHash;
    }

    public SecurityQuestion(int questionId, int userId, String question, String answerHash, Timestamp createdAt) {
        this.questionId = questionId;
        this.userId = userId;
        this.question = question;
        this.answerHash = answerHash;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswerHash() {
        return answerHash;
    }

    public void setAnswerHash(String answerHash) {
        this.answerHash = answerHash;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SecurityQuestion that = (SecurityQuestion) o;
        return questionId == that.questionId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(questionId);
    }

    @Override
    public String toString() {
        return "SecurityQuestion{" +
                "questionId=" + questionId +
                ", userId=" + userId +
                ", question='" + question + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
