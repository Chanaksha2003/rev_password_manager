package com.revature.revpassword.model;

import java.sql.Timestamp;
import java.util.Objects;

/**
 * VerificationCode entity for sensitive operations
 */
public class VerificationCode {
    private int codeId;
    private int userId;
    private String verificationCode;
    private String purpose;
    private Timestamp createdAt;
    private Timestamp expiresAt;
    private boolean isUsed;

    // Constructors
    public VerificationCode() {
    }

    public VerificationCode(int userId, String verificationCode, String purpose, Timestamp expiresAt) {
        this.userId = userId;
        this.verificationCode = verificationCode;
        this.purpose = purpose;
        this.expiresAt = expiresAt;
        this.isUsed = false;
    }

    public VerificationCode(int codeId, int userId, String verificationCode, String purpose, 
                           Timestamp createdAt, Timestamp expiresAt, boolean isUsed) {
        this.codeId = codeId;
        this.userId = userId;
        this.verificationCode = verificationCode;
        this.purpose = purpose;
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
        this.isUsed = isUsed;
    }

    // Getters and Setters
    public int getCodeId() {
        return codeId;
    }

    public void setCodeId(int codeId) {
        this.codeId = codeId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Timestamp expiresAt) {
        this.expiresAt = expiresAt;
    }

    public boolean isUsed() {
        return isUsed;
    }

    public void setUsed(boolean used) {
        isUsed = used;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VerificationCode that = (VerificationCode) o;
        return codeId == that.codeId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codeId);
    }

    @Override
    public String toString() {
        return "VerificationCode{" +
                "codeId=" + codeId +
                ", userId=" + userId +
                ", purpose='" + purpose + '\'' +
                ", expiresAt=" + expiresAt +
                ", isUsed=" + isUsed +
                '}';
    }
}
