package com.revature.revpassword.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.security.SecureRandom;

/**
 * Utility class for generating strong random passwords
 */
public class PasswordGenerator {
    private static final Logger logger = LogManager.getLogger(PasswordGenerator.class);
    private static final String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    private static final String DIGITS = "0123456789";
    private static final String SPECIAL_CHARS = "!@#$%^&*()-_=+[]{}|;:,.<>?";
    private static final SecureRandom random = new SecureRandom();

    /**
     * Generate a random password with specified parameters
     * 
     * @param length Length of the password
     * @param includeUppercase Include uppercase letters
     * @param includeLowercase Include lowercase letters
     * @param includeDigits Include numbers
     * @param includeSpecialChars Include special characters
     * @return Generated password
     */
    public static String generatePassword(int length, boolean includeUppercase, 
                                         boolean includeLowercase, boolean includeDigits, 
                                         boolean includeSpecialChars) {
        if (length < 4) {
            throw new IllegalArgumentException("Password length must be at least 4 characters");
        }

        if (!includeUppercase && !includeLowercase && !includeDigits && !includeSpecialChars) {
            throw new IllegalArgumentException("At least one character type must be selected");
        }

        StringBuilder characterSet = new StringBuilder();
        StringBuilder password = new StringBuilder();

        // Build character set based on options
        if (includeUppercase) {
            characterSet.append(UPPERCASE);
            password.append(UPPERCASE.charAt(random.nextInt(UPPERCASE.length())));
        }
        if (includeLowercase) {
            characterSet.append(LOWERCASE);
            password.append(LOWERCASE.charAt(random.nextInt(LOWERCASE.length())));
        }
        if (includeDigits) {
            characterSet.append(DIGITS);
            password.append(DIGITS.charAt(random.nextInt(DIGITS.length())));
        }
        if (includeSpecialChars) {
            characterSet.append(SPECIAL_CHARS);
            password.append(SPECIAL_CHARS.charAt(random.nextInt(SPECIAL_CHARS.length())));
        }

        // Fill remaining characters randomly
        for (int i = password.length(); i < length; i++) {
            int randomIndex = random.nextInt(characterSet.length());
            password.append(characterSet.charAt(randomIndex));
        }

        // Shuffle the password
        String shuffled = shuffleString(password.toString());
        logger.debug("Generated password of length: {}", length);
        return shuffled;
    }

    /**
     * Generate a password with default settings (all character types included)
     */
    public static String generatePassword(int length) {
        return generatePassword(length, true, true, true, true);
    }

    /**
     * Shuffle a string randomly
     */
    private static String shuffleString(String input) {
        char[] characters = input.toCharArray();
        for (int i = characters.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            char temp = characters[i];
            characters[i] = characters[j];
            characters[j] = temp;
        }
        return new String(characters);
    }

    /**
     * Validate password strength
     */
    public static boolean isStrongPassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (SPECIAL_CHARS.indexOf(c) >= 0) hasSpecial = true;
        }

        return hasUpper && hasLower && hasDigit && hasSpecial;
    }
}
