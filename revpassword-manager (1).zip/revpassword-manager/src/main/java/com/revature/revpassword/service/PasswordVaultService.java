package com.revature.revpassword.service;

import com.revature.revpassword.dao.PasswordVaultDAO;
import com.revature.revpassword.model.PasswordEntry;
import com.revature.revpassword.util.EncryptionUtil;
import com.revature.revpassword.util.PasswordGenerator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Optional;

/**
 * Service layer for Password Vault operations
 */
public class PasswordVaultService {
    private static final Logger logger = LogManager.getLogger(PasswordVaultService.class);
    private final PasswordVaultDAO passwordVaultDAO;

    public PasswordVaultService() {
        this.passwordVaultDAO = new PasswordVaultDAO();
    }

    /**
     * Add a new password entry
     */
    public boolean addPassword(int userId, String accountName, String username, 
                              String password, String websiteUrl, String notes, String masterPassword) {
        try {
            // Encrypt the password
            String encryptedPassword = EncryptionUtil.encrypt(password, masterPassword);

            // Create password entry
            PasswordEntry entry = new PasswordEntry(userId, accountName, username, 
                                                   encryptedPassword, websiteUrl, notes);

            boolean added = passwordVaultDAO.addPasswordEntry(entry);

            if (added) {
                logger.info("Password added for account: {}", accountName);
                System.out.println("Password entry added successfully!");
            } else {
                logger.error("Failed to add password for account: {}", accountName);
                System.out.println("Failed to add password entry. Please try again.");
            }

            return added;
        } catch (Exception e) {
            logger.error("Error adding password: {}", e.getMessage());
            System.out.println("Error adding password: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get all password entries for a user (without decrypting)
     */
    public List<PasswordEntry> getAllPasswords(int userId) {
        List<PasswordEntry> entries = passwordVaultDAO.getAllPasswordsByUserId(userId);
        logger.debug("Retrieved {} password entries for user ID: {}", entries.size(), userId);
        return entries;
    }

    /**
     * Get password details with decryption
     */
    public Optional<String> getDecryptedPassword(int vaultId, String masterPassword) {
        Optional<PasswordEntry> entryOpt = passwordVaultDAO.getPasswordEntryById(vaultId);

        if (entryOpt.isEmpty()) {
            logger.warn("Password entry not found: {}", vaultId);
            System.out.println("Password entry not found.");
            return Optional.empty();
        }

        try {
            PasswordEntry entry = entryOpt.get();
            String decryptedPassword = EncryptionUtil.decrypt(entry.getEncryptedPassword(), masterPassword);
            logger.debug("Password decrypted for vault ID: {}", vaultId);
            return Optional.of(decryptedPassword);
        } catch (Exception e) {
            logger.error("Error decrypting password: {}", e.getMessage());
            System.out.println("Failed to decrypt password. Invalid master password.");
            return Optional.empty();
        }
    }

    /**
     * Get password entry details
     */
    public Optional<PasswordEntry> getPasswordEntry(int vaultId) {
        return passwordVaultDAO.getPasswordEntryById(vaultId);
    }

    /**
     * Update password entry
     */
    public boolean updatePassword(int vaultId, String accountName, String username, 
                                 String newPassword, String websiteUrl, String notes, 
                                 String masterPassword) {
        Optional<PasswordEntry> entryOpt = passwordVaultDAO.getPasswordEntryById(vaultId);

        if (entryOpt.isEmpty()) {
            logger.warn("Password entry not found for update: {}", vaultId);
            System.out.println("Password entry not found.");
            return false;
        }

        try {
            PasswordEntry entry = entryOpt.get();
            
            if (accountName != null && !accountName.trim().isEmpty()) {
                entry.setAccountName(accountName);
            }
            
            if (username != null && !username.trim().isEmpty()) {
                entry.setUsername(username);
            }
            
            if (newPassword != null && !newPassword.trim().isEmpty()) {
                String encryptedPassword = EncryptionUtil.encrypt(newPassword, masterPassword);
                entry.setEncryptedPassword(encryptedPassword);
            }
            
            if (websiteUrl != null) {
                entry.setWebsiteUrl(websiteUrl);
            }
            
            if (notes != null) {
                entry.setNotes(notes);
            }

            boolean updated = passwordVaultDAO.updatePasswordEntry(entry);

            if (updated) {
                logger.info("Password entry updated: {}", vaultId);
                System.out.println("Password entry updated successfully!");
            } else {
                logger.error("Failed to update password entry: {}", vaultId);
                System.out.println("Failed to update password entry. Please try again.");
            }

            return updated;
        } catch (Exception e) {
            logger.error("Error updating password: {}", e.getMessage());
            System.out.println("Error updating password: " + e.getMessage());
            return false;
        }
    }

    /**
     * Delete password entry
     */
    public boolean deletePassword(int vaultId) {
        boolean deleted = passwordVaultDAO.deletePasswordEntry(vaultId);

        if (deleted) {
            logger.info("Password entry deleted: {}", vaultId);
            System.out.println("Password entry deleted successfully!");
        } else {
            logger.error("Failed to delete password entry: {}", vaultId);
            System.out.println("Failed to delete password entry. Please try again.");
        }

        return deleted;
    }

    /**
     * Search passwords by account name
     */
    public List<PasswordEntry> searchPasswords(int userId, String searchTerm) {
        List<PasswordEntry> results = passwordVaultDAO.searchByAccountName(userId, searchTerm);
        logger.debug("Found {} password entries matching '{}'", results.size(), searchTerm);
        return results;
    }

    /**
     * Generate a strong random password
     */
    public String generateStrongPassword(int length, boolean includeUppercase, 
                                        boolean includeLowercase, boolean includeDigits, 
                                        boolean includeSpecialChars) {
        try {
            String password = PasswordGenerator.generatePassword(length, includeUppercase, 
                                                                includeLowercase, includeDigits, 
                                                                includeSpecialChars);
            logger.debug("Generated strong password of length: {}", length);
            return password;
        } catch (Exception e) {
            logger.error("Error generating password: {}", e.getMessage());
            System.out.println("Error generating password: " + e.getMessage());
            return null;
        }
    }

    /**
     * Get password count for a user
     */
    public int getPasswordCount(int userId) {
        return passwordVaultDAO.getPasswordCountByUserId(userId);
    }
}
