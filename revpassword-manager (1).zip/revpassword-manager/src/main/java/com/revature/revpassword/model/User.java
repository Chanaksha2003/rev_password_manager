package com.revature.revpassword.model;

import java.sql.Timestamp;
import java.util.Objects;

/**
 * User entity representing a registered user in the system
 */
public class User {
    private int userId;
    private String username;
    private String email;
    private String fullName;
    private String masterPassword;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private boolean isActive;

    // Constructors
    public User() {
    }

    public User(String username, String email, String fullName, String masterPassword) {
        this.username = username;
        this.email = email;
        this.fullName = fullName;
        this.masterPassword = masterPassword;
        this.isActive = true;
    }

    public User(int userId, String username, String email, String fullName, String masterPassword, 
                Timestamp createdAt, Timestamp updatedAt, boolean isActive) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.fullName = fullName;
        this.masterPassword = masterPassword;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.isActive = isActive;
    }

    // Getters and Setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMasterPassword() {
        return masterPassword;
    }

    public void setMasterPassword(String masterPassword) {
        this.masterPassword = masterPassword;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return userId == user.userId && Objects.equals(username, user.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, username);
    }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", fullName='" + fullName + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
