package com.revature.revpassword.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;

/**
 * Utility class for encrypting and decrypting passwords
 */
public class EncryptionUtil {
    private static final Logger logger = LogManager.getLogger(EncryptionUtil.class);
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";

    /**
     * Generate a secret key from master password
     */
    private static SecretKey generateKey(String masterPassword) throws Exception {
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] key = sha.digest(masterPassword.getBytes(StandardCharsets.UTF_8));
        key = Arrays.copyOf(key, 16); // Use only first 128 bits
        return new SecretKeySpec(key, ALGORITHM);
    }

    /**
     * Encrypt a password using the master password
     */
    public static String encrypt(String password, String masterPassword) {
        try {
            SecretKey secretKey = generateKey(masterPassword);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(password.getBytes(StandardCharsets.UTF_8));
            String encrypted = Base64.getEncoder().encodeToString(encryptedBytes);
            logger.debug("Password encrypted successfully");
            return encrypted;
        } catch (Exception e) {
            logger.error("Error encrypting password: {}", e.getMessage());
            throw new RuntimeException("Encryption failed", e);
        }
    }

    /**
     * Decrypt a password using the master password
     */
    public static String decrypt(String encryptedPassword, String masterPassword) {
        try {
            SecretKey secretKey = generateKey(masterPassword);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
            String decrypted = new String(decryptedBytes, StandardCharsets.UTF_8);
            logger.debug("Password decrypted successfully");
            return decrypted;
        } catch (Exception e) {
            logger.error("Error decrypting password: {}", e.getMessage());
            throw new RuntimeException("Decryption failed - Invalid master password or corrupted data", e);
        }
    }
}
