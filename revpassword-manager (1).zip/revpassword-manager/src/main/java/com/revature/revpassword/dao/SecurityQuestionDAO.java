package com.revature.revpassword.dao;

import com.revature.revpassword.model.SecurityQuestion;
import com.revature.revpassword.util.DatabaseConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data Access Object for Security Questions
 */
public class SecurityQuestionDAO {
    private static final Logger logger = LogManager.getLogger(SecurityQuestionDAO.class);
    private final DatabaseConnection dbConnection;

    public SecurityQuestionDAO() {
        this.dbConnection = DatabaseConnection.getInstance();
    }

    /**
     * Add a security question
     */
    public boolean addSecurityQuestion(SecurityQuestion question) {
        String sql = "INSERT INTO security_questions (user_id, question, answer_hash) VALUES (?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, question.getUserId());
            pstmt.setString(2, question.getQuestion());
            pstmt.setString(3, question.getAnswerHash());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        question.setQuestionId(generatedKeys.getInt(1));
                    }
                }
                logger.info("Security question added for user ID: {}", question.getUserId());
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error adding security question: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Get all security questions for a user
     */
    public List<SecurityQuestion> getSecurityQuestionsByUserId(int userId) {
        List<SecurityQuestion> questions = new ArrayList<>();
        String sql = "SELECT * FROM security_questions WHERE user_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                questions.add(extractSecurityQuestionFromResultSet(rs));
            }
            logger.debug("Retrieved {} security questions for user ID: {}", questions.size(), userId);
        } catch (SQLException e) {
            logger.error("Error getting security questions: {}", e.getMessage());
        }
        return questions;
    }

    /**
     * Get security question by ID
     */
    public Optional<SecurityQuestion> getSecurityQuestionById(int questionId) {
        String sql = "SELECT * FROM security_questions WHERE question_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                SecurityQuestion question = extractSecurityQuestionFromResultSet(rs);
                return Optional.of(question);
            }
        } catch (SQLException e) {
            logger.error("Error getting security question by ID: {}", e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Update security question
     */
    public boolean updateSecurityQuestion(SecurityQuestion question) {
        String sql = "UPDATE security_questions SET question = ?, answer_hash = ? WHERE question_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, question.getQuestion());
            pstmt.setString(2, question.getAnswerHash());
            pstmt.setInt(3, question.getQuestionId());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                logger.info("Security question updated: {}", question.getQuestionId());
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error updating security question: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Delete security question
     */
    public boolean deleteSecurityQuestion(int questionId) {
        String sql = "DELETE FROM security_questions WHERE question_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, questionId);
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                logger.info("Security question deleted: {}", questionId);
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error deleting security question: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Delete all security questions for a user
     */
    public boolean deleteAllSecurityQuestions(int userId) {
        String sql = "DELETE FROM security_questions WHERE user_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            int affectedRows = pstmt.executeUpdate();
            logger.info("Deleted {} security questions for user ID: {}", affectedRows, userId);
            return true;
        } catch (SQLException e) {
            logger.error("Error deleting all security questions: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Extract SecurityQuestion object from ResultSet
     */
    private SecurityQuestion extractSecurityQuestionFromResultSet(ResultSet rs) throws SQLException {
        return new SecurityQuestion(
            rs.getInt("question_id"),
            rs.getInt("user_id"),
            rs.getString("question"),
            rs.getString("answer_hash"),
            rs.getTimestamp("created_at")
        );
    }
}
