package com.revature.revpassword.dao;

import com.revature.revpassword.model.PasswordEntry;
import com.revature.revpassword.util.DatabaseConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data Access Object for Password Vault operations
 */
public class PasswordVaultDAO {
    private static final Logger logger = LogManager.getLogger(PasswordVaultDAO.class);
    private final DatabaseConnection dbConnection;

    public PasswordVaultDAO() {
        this.dbConnection = DatabaseConnection.getInstance();
    }

    /**
     * Add a new password entry
     */
    public boolean addPasswordEntry(PasswordEntry entry) {
        String sql = "INSERT INTO password_vault (user_id, account_name, username, encrypted_password, website_url, notes) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, entry.getUserId());
            pstmt.setString(2, entry.getAccountName());
            pstmt.setString(3, entry.getUsername());
            pstmt.setString(4, entry.getEncryptedPassword());
            pstmt.setString(5, entry.getWebsiteUrl());
            pstmt.setString(6, entry.getNotes());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        entry.setVaultId(generatedKeys.getInt(1));
                    }
                }
                logger.info("Password entry added for account: {}", entry.getAccountName());
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error adding password entry: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Get all password entries for a user
     */
    public List<PasswordEntry> getAllPasswordsByUserId(int userId) {
        List<PasswordEntry> entries = new ArrayList<>();
        String sql = "SELECT * FROM password_vault WHERE user_id = ? ORDER BY account_name";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                entries.add(extractPasswordEntryFromResultSet(rs));
            }
            logger.debug("Retrieved {} password entries for user ID: {}", entries.size(), userId);
        } catch (SQLException e) {
            logger.error("Error getting password entries: {}", e.getMessage());
        }
        return entries;
    }

    /**
     * Get password entry by vault ID
     */
    public Optional<PasswordEntry> getPasswordEntryById(int vaultId) {
        String sql = "SELECT * FROM password_vault WHERE vault_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, vaultId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                PasswordEntry entry = extractPasswordEntryFromResultSet(rs);
                logger.debug("Password entry found: {}", vaultId);
                return Optional.of(entry);
            }
        } catch (SQLException e) {
            logger.error("Error getting password entry by ID: {}", e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Search password entries by account name
     */
    public List<PasswordEntry> searchByAccountName(int userId, String searchTerm) {
        List<PasswordEntry> entries = new ArrayList<>();
        String sql = "SELECT * FROM password_vault WHERE user_id = ? AND account_name LIKE ? ORDER BY account_name";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.setString(2, "%" + searchTerm + "%");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                entries.add(extractPasswordEntryFromResultSet(rs));
            }
            logger.debug("Found {} password entries matching '{}'", entries.size(), searchTerm);
        } catch (SQLException e) {
            logger.error("Error searching password entries: {}", e.getMessage());
        }
        return entries;
    }

    /**
     * Update password entry
     */
    public boolean updatePasswordEntry(PasswordEntry entry) {
        String sql = "UPDATE password_vault SET account_name = ?, username = ?, encrypted_password = ?, " +
                     "website_url = ?, notes = ?, updated_at = CURRENT_TIMESTAMP WHERE vault_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, entry.getAccountName());
            pstmt.setString(2, entry.getUsername());
            pstmt.setString(3, entry.getEncryptedPassword());
            pstmt.setString(4, entry.getWebsiteUrl());
            pstmt.setString(5, entry.getNotes());
            pstmt.setInt(6, entry.getVaultId());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                logger.info("Password entry updated: {}", entry.getAccountName());
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error updating password entry: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Delete password entry
     */
    public boolean deletePasswordEntry(int vaultId) {
        String sql = "DELETE FROM password_vault WHERE vault_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, vaultId);
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                logger.info("Password entry deleted: {}", vaultId);
                return true;
            }
        } catch (SQLException e) {
            logger.error("Error deleting password entry: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Get count of password entries for a user
     */
    public int getPasswordCountByUserId(int userId) {
        String sql = "SELECT COUNT(*) FROM password_vault WHERE user_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            logger.error("Error getting password count: {}", e.getMessage());
        }
        return 0;
    }

    /**
     * Extract PasswordEntry object from ResultSet
     */
    private PasswordEntry extractPasswordEntryFromResultSet(ResultSet rs) throws SQLException {
        return new PasswordEntry(
            rs.getInt("vault_id"),
            rs.getInt("user_id"),
            rs.getString("account_name"),
            rs.getString("username"),
            rs.getString("encrypted_password"),
            rs.getString("website_url"),
            rs.getString("notes"),
            rs.getTimestamp("created_at"),
            rs.getTimestamp("updated_at")
        );
    }
}
