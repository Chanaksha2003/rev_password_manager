package com.revature.revpassword.service;

import com.revature.revpassword.dao.SecurityQuestionDAO;
import com.revature.revpassword.dao.UserDAO;
import com.revature.revpassword.model.SecurityQuestion;
import com.revature.revpassword.model.User;
import com.revature.revpassword.util.PasswordHashUtil;
import com.revature.revpassword.util.ValidationUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Optional;

/**
 * Service layer for User-related business logic
 */
public class UserService {
    private static final Logger logger = LogManager.getLogger(UserService.class);
    private final UserDAO userDAO;
    private final SecurityQuestionDAO securityQuestionDAO;

    public UserService() {
        this.userDAO = new UserDAO();
        this.securityQuestionDAO = new SecurityQuestionDAO();
    }

    /**
     * Register a new user
     */
    public boolean registerUser(String username, String email, String fullName, String masterPassword) {
        // Validate inputs
        if (!ValidationUtil.isValidUsername(username)) {
            logger.warn("Invalid username format: {}", username);
            System.out.println("Invalid username. Must be 3-20 characters, alphanumeric and underscores only.");
            return false;
        }

        if (!ValidationUtil.isValidEmail(email)) {
            logger.warn("Invalid email format: {}", email);
            System.out.println("Invalid email format.");
            return false;
        }

        if (!ValidationUtil.isValidPassword(masterPassword)) {
            logger.warn("Weak master password provided");
            System.out.println(ValidationUtil.getPasswordStrengthMessage());
            return false;
        }

        // Check if username or email already exists
        if (userDAO.findByUsername(username).isPresent()) {
            logger.warn("Username already exists: {}", username);
            System.out.println("Username already exists. Please choose a different username.");
            return false;
        }

        if (userDAO.findByEmail(email).isPresent()) {
            logger.warn("Email already exists: {}", email);
            System.out.println("Email already exists. Please use a different email.");
            return false;
        }

        // Hash the master password
        String hashedPassword = PasswordHashUtil.hashPassword(masterPassword);

        // Create user
        User user = new User(username, email, fullName, hashedPassword);
        boolean created = userDAO.createUser(user);

        if (created) {
            logger.info("User registered successfully: {}", username);
            System.out.println("User registered successfully!");
        } else {
            logger.error("Failed to register user: {}", username);
            System.out.println("Failed to register user. Please try again.");
        }

        return created;
    }

    /**
     * Authenticate user login
     */
    public Optional<User> login(String username, String masterPassword) {
        Optional<User> userOpt = userDAO.findByUsername(username);

        if (userOpt.isEmpty()) {
            logger.warn("Login attempt with non-existent username: {}", username);
            System.out.println("Invalid username or password.");
            return Optional.empty();
        }

        User user = userOpt.get();
        
        if (!PasswordHashUtil.verifyPassword(masterPassword, user.getMasterPassword())) {
            logger.warn("Login attempt with incorrect password for user: {}", username);
            System.out.println("Invalid username or password.");
            return Optional.empty();
        }

        logger.info("User logged in successfully: {}", username);
        return Optional.of(user);
    }

    /**
     * Update user profile
     */
    public boolean updateProfile(int userId, String newEmail, String newFullName) {
        Optional<User> userOpt = userDAO.findById(userId);

        if (userOpt.isEmpty()) {
            logger.warn("Update profile attempt for non-existent user ID: {}", userId);
            return false;
        }

        User user = userOpt.get();

        if (ValidationUtil.isNotEmpty(newEmail) && !newEmail.equals(user.getEmail())) {
            if (!ValidationUtil.isValidEmail(newEmail)) {
                logger.warn("Invalid email format during profile update: {}", newEmail);
                System.out.println("Invalid email format.");
                return false;
            }

            // Check if new email is already taken
            Optional<User> existingUser = userDAO.findByEmail(newEmail);
            if (existingUser.isPresent() && existingUser.get().getUserId() != userId) {
                logger.warn("Email already in use: {}", newEmail);
                System.out.println("Email already in use by another account.");
                return false;
            }

            user.setEmail(newEmail);
        }

        if (ValidationUtil.isNotEmpty(newFullName)) {
            user.setFullName(newFullName);
        }

        boolean updated = userDAO.updateUser(user);

        if (updated) {
            logger.info("User profile updated successfully for user ID: {}", userId);
            System.out.println("Profile updated successfully!");
        } else {
            logger.error("Failed to update profile for user ID: {}", userId);
            System.out.println("Failed to update profile. Please try again.");
        }

        return updated;
    }

    /**
     * Change master password
     */
    public boolean changeMasterPassword(int userId, String oldPassword, String newPassword) {
        Optional<User> userOpt = userDAO.findById(userId);

        if (userOpt.isEmpty()) {
            logger.warn("Password change attempt for non-existent user ID: {}", userId);
            return false;
        }

        User user = userOpt.get();

        // Verify old password
        if (!PasswordHashUtil.verifyPassword(oldPassword, user.getMasterPassword())) {
            logger.warn("Incorrect old password during password change for user ID: {}", userId);
            System.out.println("Incorrect current password.");
            return false;
        }

        // Validate new password
        if (!ValidationUtil.isValidPassword(newPassword)) {
            logger.warn("Weak new password provided");
            System.out.println(ValidationUtil.getPasswordStrengthMessage());
            return false;
        }

        // Hash new password
        String hashedNewPassword = PasswordHashUtil.hashPassword(newPassword);

        boolean updated = userDAO.updateMasterPassword(userId, hashedNewPassword);

        if (updated) {
            logger.info("Master password changed successfully for user ID: {}", userId);
            System.out.println("Master password changed successfully!");
        } else {
            logger.error("Failed to change master password for user ID: {}", userId);
            System.out.println("Failed to change password. Please try again.");
        }

        return updated;
    }

    /**
     * Recover password using security questions
     */
    public boolean recoverPassword(String username) {
        Optional<User> userOpt = userDAO.findByUsername(username);

        if (userOpt.isEmpty()) {
            logger.warn("Password recovery attempt for non-existent username: {}", username);
            System.out.println("Username not found.");
            return false;
        }

        User user = userOpt.get();
        List<SecurityQuestion> questions = securityQuestionDAO.getSecurityQuestionsByUserId(user.getUserId());

        if (questions.isEmpty()) {
            logger.warn("No security questions set for user: {}", username);
            System.out.println("No security questions found. Cannot recover password.");
            return false;
        }

        logger.info("Password recovery initiated for user: {}", username);
        return true;
    }

    /**
     * Get user by ID
     */
    public Optional<User> getUserById(int userId) {
        return userDAO.findById(userId);
    }

    /**
     * Get user by username
     */
    public Optional<User> getUserByUsername(String username) {
        return userDAO.findByUsername(username);
    }
}
